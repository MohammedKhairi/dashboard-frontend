<?php
$lid=isset($_GET['lid'])?$_GET['lid']:"";
$s_page=isset($_GET['s_page'])?$_GET['s_page']:"";
$cat_id=isset($_GET['cat_id'])?$_GET['cat_id']:"";
$sub_cat=isset($_GET['sub_cat'])?$_GET['sub_cat']:"";
$id=isset($_GET['post_id'])?$_GET['post_id']:"";

echo "lid=".$lid."<br>";
echo "s_page=".$s_page."<br>";
echo "cat_id=".$cat_id."<br>";
echo "sub_cat=".$sub_cat."<br>";
echo "id=".$id."<br>";